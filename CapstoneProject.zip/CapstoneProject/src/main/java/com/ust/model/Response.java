package com.ust.model;

import java.util.List;

import org.springframework.stereotype.Component;

import com.ust.entity.Bank;
import com.ust.entity.Customer;
import com.ust.entity.FundTransfer;

@Component
public class Response {
	private String status;
	private List<Bank>bank;
	private List<Customer>customer;
	private List<FundTransfer>fundtransfer;
	public String getStatus() {
		return status;
	}
	public List<Bank> getBank() {
		return bank;
	}
	public void setBank(List<Bank> bank) {
		this.bank = bank;
	}
	public List<Customer> getCustomer() {
		return customer;
	}
	public void setCustomer(List<Customer> customer) {
		this.customer = customer;
	}
	public List<FundTransfer> getFundtransfer() {
		return fundtransfer;
	}
	public void setFundtransfer(List<FundTransfer> fundtransfer) {
		this.fundtransfer = fundtransfer;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
	
